from cv2 import cv2
img = cv2.imread('Yusa.png')
cv_color = cv2.cvtColor(img, cv2.COLOR_BGR2YCrCb)
cv2.imwrite('img.png', cv_color)